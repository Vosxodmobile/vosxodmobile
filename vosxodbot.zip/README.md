# Vosxod Bot
Telegram bot for order collection and forwarding to admin.